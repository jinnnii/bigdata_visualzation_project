package com.kej.security_board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.kej.demo1.domain;

import lombok.Data;

@Data
public class MemberVO {
	private String id;
	private String pass;
	private String name;
}
